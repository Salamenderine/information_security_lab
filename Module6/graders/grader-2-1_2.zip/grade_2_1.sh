#!/bin/bash
#$1 : number of test cases

PATH_TO_VM_IMAGE=isl-lab-2022.ova
USERNAME=isl
PW=isl
SCP_PORT=2222
SSH_PORT=2222
TASK_FOLDER="/home/isl/t2_1"
OP_FOLDER="/home/isl/t2_1/output"
SAMPLES_FOLDER="/home/isl/t2_1/samples"
TIME=10
VM_NAME=isl-lab-2022-grade
FILE_NAME=submit_2_1.py
rm -f oput_*

if ! VBoxManage list vms | grep $VM_NAME; then  
    VBoxManage import $PATH_TO_VM_IMAGE --vsys 0 --vmname $VM_NAME
else 
    echo "[GRADER] VM by name $VM_NAME already exists. Not importing new VM. To import a fresh VM delete the existsing VM first"
fi

if ! VBoxManage list runningvms | grep $VM_NAME; then 
    VBoxManage startvm "$VM_NAME" --type headless
else 
    echo "[GRADER] VM by name $VM_NAME is already running. Not restarting it."
fi

sleep 5

sshpass -p "$PW" scp -P $SCP_PORT -o StrictHostKeyChecking=no $FILE_NAME $USERNAME@127.0.0.1:$TASK_FOLDER
ret=$?
if [ $ret -ne 0 ]; then
	echo "[GRADER] Error copying solution script. Please check logs"
	exit 1
fi

echo '[GRADER] copied solution solution python file to VM'
sshpass -p "$PW" ssh -p $SSH_PORT -o StrictHostKeyChecking=no $USERNAME@127.0.0.1 rm -f $TASK_FOLDER/password_checker_1
sshpass -p "$PW" ssh -p $SSH_PORT -o StrictHostKeyChecking=no $USERNAME@127.0.0.1 rm -rf $OP_FOLDER
sshpass -p "$PW" ssh -p $SSH_PORT -o StrictHostKeyChecking=no $USERNAME@127.0.0.1 mkdir $OP_FOLDER
NO_TESTS=5
if [ ! -z  "$1" ]; then
    NO_TESTS=$1
fi

for (( i=1;i<=$NO_TESTS;i++ ))
do
    sshpass -p "$PW" ssh -p $SSH_PORT -o StrictHostKeyChecking=no $USERNAME@127.0.0.1 timeout $TIME python3 $TASK_FOLDER/$FILE_NAME $SAMPLES_FOLDER/$i/traces $i
done

if ! sshpass -p "$PW" scp -P $SCP_PORT -o StrictHostKeyChecking=no $USERNAME@127.0.0.1:$OP_FOLDER/oput_* .; then
    echo "[GRADER] No output files generated to read"
fi



